package entidades;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Aluno extends Pessoa {
	
	private float[] notas;
	private final int quantidade = 4;
	
	public Aluno() {
		notas = new float[this.quantidade];
	}

	public float[] getNotas() {
		return notas;
	}

	public void setNotas(float[] notas) {
		this.notas = notas;
	}
	
	public float getMedia() {
		float soma = 0f;
		for (int i = 0; i < this.quantidade ; i++) {
			soma += this.getNotas()[i];
		}
		return soma/this.quantidade;
	}

	@Override
	public String toString() {
		return "Aluno\nnome: " + super.getNome() + "\nnotas: " + Arrays.asList(this.getNotas()) + "\nmédia: " + this.getMedia() + "]";
	}
	
}
