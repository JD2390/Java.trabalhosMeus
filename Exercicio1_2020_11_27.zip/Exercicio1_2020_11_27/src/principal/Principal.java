package principal;

import entidades.Aluno;

public class Principal {

	public static void main(String[] args) {
		
		Aluno aluno = new Aluno();
		aluno.setNome("Nando Carvalho");
		float[] notasDoAluno = new float[4];
		notasDoAluno[0] = 7.5f;
		notasDoAluno[1] = 9.0f;
		notasDoAluno[2] = 6.0f;
		notasDoAluno[3] = 9.2f;
		aluno.setNotas(notasDoAluno);
		
		System.out.println(aluno);

	}

}
